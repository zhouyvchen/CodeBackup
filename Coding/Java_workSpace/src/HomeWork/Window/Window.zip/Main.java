package src.HomeWork.Window;

public class Main {
    public static void main(String[] args) {
        Login L = new Login();
        L.setVisible(true);
    }
}
